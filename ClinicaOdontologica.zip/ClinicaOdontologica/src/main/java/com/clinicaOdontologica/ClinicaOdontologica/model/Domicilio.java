package com.clinicaOdontologica.ClinicaOdontologica.model;
/*1*/
//LO PRIMERO QUE HACEMOS ES CREAR LOS PAQUETES Y LAS CLASES MODELO.
//NO OLVIDAR EL H2 Y LOG4J EN EL STRUCTURE DEL PROYECTO, AH, TB EL PROPERTIES.
public class Domicilio {
    //atributos de la clase.

    private Integer id;
    private String calle;
    private Integer numero;
    private  String localidad;
    private String provincia;
//generamos dos constructores debido  a que en uno se nos solicitará que sea autoincremental y en el otro lo voy a recuperar de la bdd.
    public Domicilio(String calle, Integer numero, String localidad, String provincia) {
        this.calle = calle;
        this.numero = numero;
        this.localidad = localidad;
        this.provincia = provincia;
    }

    public Domicilio(Integer id, String calle, Integer numero, String localidad, String provincia) {
        this.id = id;
        this.calle = calle;
        this.numero = numero;
        this.localidad = localidad;
        this.provincia = provincia;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getCalle() {
        return calle;
    }

    public void setCalle(String calle) {
        this.calle = calle;
    }

    public Integer getNumero() {
        return numero;
    }

    public void setNumero(Integer numero) {
        this.numero = numero;
    }

    public String getLocalidad() {
        return localidad;
    }

    public void setLocalidad(String localidad) {
        this.localidad = localidad;
    }

    public String getProvincia() {
        return provincia;
    }

    public void setProvincia(String provincia) {
        this.provincia = provincia;
    }
}
