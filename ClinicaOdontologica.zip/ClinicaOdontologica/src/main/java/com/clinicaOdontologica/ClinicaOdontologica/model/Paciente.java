package com.clinicaOdontologica.ClinicaOdontologica.model;

import java.time.LocalDate;

/*2*/
public class Paciente {
    //atrtibutos de la clase

    private Integer id;
    private String nombre;
    private String apellido;
    private String cedula;
    private LocalDate fechaDeIngreso; //usamos el localdate de java .time pq es mas actual.
    private Domicilio domicilio; //vincularemos un paciente con un domicilio
    private String email;

    public Paciente(String nombre, String apellido, String cedula, LocalDate fechaDeIngreso, Domicilio domicilio, String email) {
        this.nombre = nombre;
        this.apellido = apellido;
        this.cedula = cedula;
        this.fechaDeIngreso = fechaDeIngreso;
        this.domicilio = domicilio;
        this.email=email;
    }
//generamos dos constructores para poder recibir el id de la bdd y el otro para recuperarlo.
    public Paciente(Integer id, String nombre, String apellido, String cedula, LocalDate fechaDeIngreso, Domicilio domicilio, String email) {
        this.id = id;
        this.nombre = nombre;
        this.apellido = apellido;
        this.cedula = cedula;
        this.fechaDeIngreso = fechaDeIngreso;
        this.domicilio = domicilio;
        this.email=email;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public String getCedula() {
        return cedula;
    }

    public void setCedula(String cedula) {
        this.cedula = cedula;
    }

    public LocalDate getFechaDeIngreso() {
        return fechaDeIngreso;
    }

    public void setFechaDeIngreso(LocalDate fechaDeIngreso) {
        this.fechaDeIngreso = fechaDeIngreso;
    }

    public Domicilio getDomicilio() {
        return domicilio;
    }

    public void setDomicilio(Domicilio domicilio) {
        this.domicilio = domicilio;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }
}
