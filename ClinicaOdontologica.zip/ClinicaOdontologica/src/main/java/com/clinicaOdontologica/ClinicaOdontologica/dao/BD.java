package com.clinicaOdontologica.ClinicaOdontologica.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class BD {
    //aca vamos a preparar los SQL que necesitemos
    //ID,CALLE,NUMERO,LOCALIDAD,PROVINCIA
    //ID, NOMBRE,APELLIDO,CEDULA, LOCAL FECHADEINGRESO, DOMICILIO
    private static final String SQL_DROP_CREATE_DOMICILIOS="DROP TABLE IF EXISTS DOMICILIOS;"+
            "CREATE TABLE DOMICILIOS (ID INT AUTO_INCREMENT PRIMARY KEY, CALLE VARCHAR(100) NOT NULL, NUMERO INT NOT NULL, LOCALIDAD VARCHAR(100) NOT NULL, PROVINCIA VARCHAR(100) NOT NULL )";
    private static final String SQL_DROP_CREATE_PACIENTES="DROP TABLE IF EXISTS PACIENTES;"+
            "CREATE TABLE PACIENTES (ID INT AUTO_INCREMENT PRIMARY KEY, NOMBRE VARCHAR(100) NOT NULL, " +
            "APELLIDO VARCHAR(100) NOT NULL, CEDULA VARCHAR(100) NOT NULL, FECHA_INGRESO DATE NOT NULL, DOMICILIO_ID INT NOT NULL, EMAIL VARCHAR(100) NOT NULL)"; //<-- FK CLAVE FORANEA
    private static final String SQL_PRUEBA="INSERT INTO DOMICILIOS(CALLE, NUMERO, LOCALIDAD, PROVINCIA) VALUES('JARAMILLO','85','LA RIOJA','LA RIOJA'), ('LAVALLE','3015','CABA','BS AS');"+
            " INSERT INTO PACIENTES (NOMBRE, APELLIDO, CEDULA, FECHA_INGRESO,DOMICILIO_ID, EMAIL)" +
            " VALUES('MATEO','CHUTT','123445','2023-02-13','1','mateo@digitalhouse.com'),('DIEGO', 'MESSI','12345', '2021-10-22','2','diegomessi@prueba.com')";
   public static Connection getConnection() throws Exception{
       Class.forName("org.h2.Driver");
       return DriverManager.getConnection("jdbc:h2:~/test","sa","sa");
   }
    public static void crearTablas(){
        //previar la conexion.
        Connection connection=null;
        try{
            connection=getConnection();
            Statement statement= connection.createStatement();
            statement.execute(SQL_DROP_CREATE_DOMICILIOS);
            statement.execute(SQL_DROP_CREATE_PACIENTES);
            statement.execute(SQL_PRUEBA);

        }catch (Exception e){
            e.printStackTrace();
        }finally {
            try {
                connection.close();
            }catch (SQLException ex){
                ex.printStackTrace();
            }
        }
    }
}
