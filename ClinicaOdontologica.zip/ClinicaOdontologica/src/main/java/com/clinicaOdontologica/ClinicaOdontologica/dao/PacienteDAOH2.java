package com.clinicaOdontologica.ClinicaOdontologica.dao;

import com.clinicaOdontologica.ClinicaOdontologica.model.Domicilio;
import com.clinicaOdontologica.ClinicaOdontologica.model.Paciente;
import org.apache.log4j.Logger;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class PacienteDAOH2 implements iDao<Paciente>{
    private static final Logger LOGGER= Logger.getLogger(PacienteDAOH2.class);
    private static final String SQL_SELECT_ALL="SELECT * FROM PACIENTES";
    private static final String SQL_SELECT_ONE="SELECT * FROM PACIENTES WHERE ID=?";
    private static final String SQL_SELECT_BY_EMAIL="SELECT * FROM PACIENTES WHERE EMAIL=?";
    @Override
    public Paciente guardar(Paciente paciente) {
        LOGGER.info("Iniciando una operación de guardado de un Paciente");

        return null;
    }

    @Override
    public Paciente buscar(Integer id) {
        LOGGER.info("Iniciando una operación de buscar de un Paciente");
        Connection connection=null;//buenas practicas
        Paciente paciente=null;
        Domicilio domicilio=null;
        try{
            connection=BD.getConnection(); //metodo que saca de la clase BD
            Statement statement= connection.createStatement();
            PreparedStatement ps_selectOne= connection.prepareStatement(SQL_SELECT_ONE);
            //consulta parametrizada pasar los valores de los???. recordemos la ubicacion y el valor.
            ps_selectOne.setInt(1,id);
            ResultSet rs= ps_selectOne.executeQuery();
            DomicilioDAOH2 daoAux= new DomicilioDAOH2();
            while(rs.next()){
                domicilio=daoAux.buscar(rs.getInt(6));
                paciente=new Paciente(rs.getInt(1),rs.getString(2),rs.getString(3),rs.getString(4),rs.getDate(5).toLocalDate(),domicilio,rs.getString(7));

            }


        }catch (Exception e){
            e.printStackTrace();
        }finally {
            try {
                connection.close();
            }catch (SQLException ex){
                ex.printStackTrace();
            }
        }
        return paciente;
    }

    @Override
    public void actualizar(Paciente paciente) {
        LOGGER.info("Iniciando una operación de actualizar un paciente");

    }

    @Override
    public void eliminar(Integer id) {
        LOGGER.info("Iniciando una operación de eliminar un paciente");

    }

    @Override
    public List<Paciente> buscarTodos() {
        LOGGER.info("Iniciando una operación de buscado de todos los pacientes");
        Connection connection=null;
        //tenemos que devolver la lista
        List<Paciente> pacientes= new ArrayList<>();
        Paciente paciente=null;
        Domicilio domicilio=null;
        try {
            connection= BD.getConnection();
            PreparedStatement ps_Select_All=connection.prepareStatement(SQL_SELECT_ALL);
            ResultSet rs= ps_Select_All.executeQuery();
            DomicilioDAOH2 daoAux= new DomicilioDAOH2();
            while(rs.next()){
                paciente= new Paciente(rs.getInt(1),rs.getString(2),rs.getString(3),rs.getString(4),rs.getDate(5).toLocalDate(),domicilio,rs.getString(7));
                pacientes.add(paciente);
            }

        }catch (Exception e){
            e.printStackTrace();

        }finally {
            try {
                connection.close();
            }catch (SQLException ex){
                ex.printStackTrace();

            }
        }
        return pacientes;
    }

    @Override
    public Paciente buscarPorString(String valor) {
        LOGGER.info("Iniciando la busqueda de un paciente por email: "+valor);
        Connection connection=null;
        Paciente paciente= null;
        Domicilio domicilio=null;
        try{
            connection=BD.getConnection();
            PreparedStatement psSelectOne=connection.prepareStatement(SQL_SELECT_BY_EMAIL);
            psSelectOne.setString(1,valor);//esto resuelto a nivel DAO
            ResultSet rs=psSelectOne.executeQuery();
            DomicilioDAOH2 daoAux=new DomicilioDAOH2();

            while (rs.next()){
                domicilio=daoAux.buscar(rs.getInt(6));
                paciente= new Paciente(rs.getInt(1),rs.getString(2),rs.getString(3),rs.getString(4),rs.getDate(5).toLocalDate(),domicilio,rs.getString(7));
            }

        }catch (Exception e){
            e.printStackTrace();
        }finally {
            try{
                connection.close();
            }catch (SQLException ex){
                ex.printStackTrace();
            }
        }

        return paciente;
    }

}
