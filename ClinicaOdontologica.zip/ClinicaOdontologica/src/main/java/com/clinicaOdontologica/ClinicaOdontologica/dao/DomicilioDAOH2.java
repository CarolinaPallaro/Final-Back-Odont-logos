package com.clinicaOdontologica.ClinicaOdontologica.dao;

import com.clinicaOdontologica.ClinicaOdontologica.model.Domicilio;
import com.clinicaOdontologica.ClinicaOdontologica.model.Paciente;
import org.apache.log4j.Logger;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class DomicilioDAOH2 implements iDao<Domicilio>{
    //hacemos los logger siempre es el logger de apache.
    private static final Logger LOGGER= Logger.getLogger(DomicilioDAOH2.class);
    private static final String SQL_INSERT="INSERT INTO DOMICILIOS (CALLE, NUMERO, LOCALIDAD, PROVINCIA) VALUES(?,?,?,?)";
    private static final String SQL_SELECT_ONE="SELECT * FROM DOMICILIOS WHERE ID=?";
    private static final String SQL_DELETE="DELETE FROM DOMICILIOS WHERE ID=?";
    private static final String SQL_SELECT_ALL="SELECT * FROM DOMICILIOS";
    private static final String SQL_UPDATE="UPDATE DOMICILIOS SET CALLE=?, NUMERO=?, LOCALIDAD=?, PROVINCIA=? WHERE ID=?";
    @Override
    public Domicilio guardar(Domicilio domicilio) {
        LOGGER.info("Iniciando una operación de guardado de un domicilio");
        Connection connection=null;
        try{
            connection=BD.getConnection(); //metodo que saca de la clase BD
            PreparedStatement ps_insert= connection.prepareStatement(SQL_INSERT,Statement.RETURN_GENERATED_KEYS); //al estar sobre cargado(2 const) tenemos un metodo para devolver un key si esta esta creada.
            //consulta parametrizada pasar los valores de los???. recordemos la ubicacion y el valor.
            ps_insert.setString(1,domicilio.getCalle());
            ps_insert.setInt(2,domicilio.getNumero());
            ps_insert.setString(3,domicilio.getLocalidad());
            ps_insert.setString(4, domicilio.getProvincia());
            ps_insert.execute(); //id se pone solito pq es autoincremental
            ResultSet rs= ps_insert.getGeneratedKeys();//invocando el metodo que devuelve esa clave
           while(rs.next()) {
               domicilio.setId(rs.getInt(1));
           }


        }catch (Exception e){
            e.printStackTrace();
        }finally {
            try {
                connection.close();
            }catch (SQLException ex){
                ex.printStackTrace();
            }
        }
        return domicilio;
    }

    @Override
    public Domicilio buscar(Integer id) {
        LOGGER.info("Iniciando una operación de buscar por id a un domicilio");
        Connection connection=null;
        Domicilio domicilio=null;
        try{
            connection=BD.getConnection(); //metodo que saca de la clase BD
            PreparedStatement ps_Select= connection.prepareStatement(SQL_SELECT_ONE);
            ps_Select.setInt(1,id);
            ResultSet rs= ps_Select.executeQuery();
            while(rs.next()) {
                domicilio= new Domicilio(rs.getInt(1),rs.getString(2),rs.getInt(3),rs.getString(4),rs.getString(5));
                            }


        }catch (Exception e){
            e.printStackTrace();
        }finally {
            try {
                connection.close();
            }catch (SQLException ex){
                ex.printStackTrace();
            }
        }

        return domicilio ;
    }

    @Override
    public void actualizar(Domicilio domicilio) {
        LOGGER.info("Iniciando una operación de actualizado de un domicilio con id:"+domicilio);
        Connection connection=null;
        try{
            connection=BD.getConnection(); //metodo que saca de la clase BD
            PreparedStatement ps_update= connection.prepareStatement(SQL_UPDATE);
            ps_update.setString(1,domicilio.getCalle());
            ps_update.setInt(2,domicilio.getNumero());
            ps_update.setString(3, domicilio.getLocalidad());
            ps_update.setString(4, domicilio.getProvincia());
            ps_update.setInt(5,domicilio.getId());
            ps_update.execute();
        }catch (Exception e){
            e.printStackTrace();
        }finally {
            try {
                connection.close();
            }catch (SQLException ex){
                ex.printStackTrace();
            }
        }


    }

    @Override
    public void eliminar(Integer id) {
        LOGGER.info("Iniciando una operación de  eliminación de un domicilio: "+id);
        Connection connection=null;
        try{
            connection=BD.getConnection();
            PreparedStatement ps_delete=connection.prepareStatement(SQL_DELETE);
            ps_delete.setInt(1,id);
            ps_delete.execute();

        }catch(Exception e){
            e.printStackTrace();

        }finally {
            try {
                connection.close();
            }catch (SQLException ex){
                ex.printStackTrace();
            }
        }

    }

    @Override
    public List<Domicilio> buscarTodos() {
        LOGGER.info("Iniciando la operación de buscado de todos los domicilios");
        Connection connection=null;
        List<Domicilio> domicilios=new ArrayList<>();
        Domicilio domicilio=null;
        try{
            connection=BD.getConnection();
            PreparedStatement ps_Select_all=connection.prepareStatement(SQL_SELECT_ALL);
            ResultSet rs=ps_Select_all.executeQuery();
            while (rs.next()){
                //como hacemos para trabajar con la lista de Pablo?
                domicilio= new Domicilio(rs.getInt(1),rs.getString(2),rs.getInt(3),rs.getString(4),rs.getString(5));
                domicilios.add(domicilio);
            }

        }catch (Exception e){
            e.printStackTrace();

        }finally {
            try {
                connection.close();
            }catch (SQLException ex){
                ex.printStackTrace();

            }
        }
        return domicilios;
    }

    @Override
    public Domicilio buscarPorString(String valor) {
        return null;
    }
}
