package com.clinicaOdontologica.ClinicaOdontologica.dao;
/*3*/
// generamos el iDao para que despues pueda funcionar el DAOH2 de las clases y asi pueda aplicar poliformismo.

import java.util.List;

public interface iDao<T> {
    T guardar(T t);
    T buscar(Integer id);
    void actualizar(T t);
    void eliminar(Integer id);
    List<T> buscarTodos(); //para buscar todo la bdd nos va a devolver una coleccion.-
    T buscarPorString(String valor);
}
