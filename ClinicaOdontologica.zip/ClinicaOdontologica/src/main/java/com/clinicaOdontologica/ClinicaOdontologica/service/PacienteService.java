package com.clinicaOdontologica.ClinicaOdontologica.service;

import com.clinicaOdontologica.ClinicaOdontologica.dao.PacienteDAOH2;
import com.clinicaOdontologica.ClinicaOdontologica.dao.iDao;
import com.clinicaOdontologica.ClinicaOdontologica.model.Paciente;
import org.springframework.stereotype.Service;

import java.util.List;

//creamos el iDAO
@Service
public class PacienteService {
    //definimos el atributo
    private iDao<Paciente> pacienteiDao;

    public PacienteService() {
        this.pacienteiDao = new PacienteDAOH2();
    }
    public Paciente guardarPaciente(Paciente paciente){
        return pacienteiDao.guardar(paciente);
    }
    public Paciente buscarPaciente(Integer id){
        return pacienteiDao.buscar(id);
    }
    public void eliminarPaciente(Integer id){
        //lleva return?
        pacienteiDao.eliminar(id);
    }
    public void actualizarPaciente(Paciente paciente){
        pacienteiDao.actualizar(paciente);
    }
    public List<Paciente> buscarPacientes(){
        return pacienteiDao.buscarTodos();
    }
    public Paciente buscarPacientePorCorreo(String correo){
        return pacienteiDao.buscarPorString(correo);
    }

}
